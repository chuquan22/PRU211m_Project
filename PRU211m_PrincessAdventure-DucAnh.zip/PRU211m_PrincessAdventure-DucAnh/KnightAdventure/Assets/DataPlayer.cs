using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataPlayer : MonoBehaviour
{
    public static int maxHealth = 100;

    public static int currentHeath = 100;

    public static int attackDamage = 20;

    public static int maxValueExp = 100;

    public static int valueExp = 0;

    public static int level = 0;
    
}
